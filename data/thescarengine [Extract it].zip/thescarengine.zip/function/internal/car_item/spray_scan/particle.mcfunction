#ran by data\\thescarengine\\function\\internal\\car_item\\spray_scan\\main.mcfunction

#get full color from spray can (26.1.2: dyed_color is a direct RGB integer)
execute store result score .internal.item.spray_can.rgb datapack.temp.thecarengine.main run data get storage thescarengine:temp data.internal.spray_item.used_data.components.'minecraft:dyed_color'

# RED = (C / 65536) / 256
scoreboard players operation .internal.item.spray_can.rgb.r datapack.temp.thecarengine.main = .internal.item.spray_can.rgb datapack.temp.thecarengine.main
scoreboard players operation .internal.item.spray_can.rgb.r datapack.temp.thecarengine.main /= .65536 datapack.temp.thecarengine.const
execute store result storage thescarengine:temp data.internal.spray_item.rgb.r int 1 run scoreboard players get .internal.item.spray_can.rgb.r datapack.temp.thecarengine.main
execute store result storage thescarengine:temp data.internal.spray_item.rgb.r float 0.00390625 run data get storage thescarengine:temp data.internal.spray_item.rgb.r 1

# GREEN = (C / 256) % 256
scoreboard players operation .internal.item.spray_can.rgb.g datapack.temp.thecarengine.main = .internal.item.spray_can.rgb datapack.temp.thecarengine.main
scoreboard players operation .internal.item.spray_can.rgb.g datapack.temp.thecarengine.main /= .256 datapack.temp.thecarengine.const
scoreboard players operation .internal.item.spray_can.rgb.g datapack.temp.thecarengine.main %= .256 datapack.temp.thecarengine.const
execute store result storage thescarengine:temp data.internal.spray_item.rgb.g int 1 run scoreboard players get .internal.item.spray_can.rgb.g datapack.temp.thecarengine.main
execute store result storage thescarengine:temp data.internal.spray_item.rgb.g float 0.00390625 run data get storage thescarengine:temp data.internal.spray_item.rgb.g 1

# BLUE = C % 256
scoreboard players operation .internal.item.spray_can.rgb.b datapack.temp.thecarengine.main = .internal.item.spray_can.rgb datapack.temp.thecarengine.main
scoreboard players operation .internal.item.spray_can.rgb.b datapack.temp.thecarengine.main %= .256 datapack.temp.thecarengine.const
execute store result storage thescarengine:temp data.internal.spray_item.rgb.b int 1 run scoreboard players get .internal.item.spray_can.rgb.b datapack.temp.thecarengine.main
execute store result storage thescarengine:temp data.internal.spray_item.rgb.b float 0.00390625 run data get storage thescarengine:temp data.internal.spray_item.rgb.b 1

#convert floats into strings
data modify storage thescarengine:temp data.internal.spray_item.rgb.r set string storage thescarengine:temp data.internal.spray_item.rgb.r 0 -1
data modify storage thescarengine:temp data.internal.spray_item.rgb.g set string storage thescarengine:temp data.internal.spray_item.rgb.g 0 -1
data modify storage thescarengine:temp data.internal.spray_item.rgb.b set string storage thescarengine:temp data.internal.spray_item.rgb.b 0 -1

function thescarengine:internal/car_item/spray_scan/particle_macro with storage thescarengine:temp data.internal.spray_item.rgb

playsound minecraft:block.fire.extinguish player @a ~ ~ ~ 1 1.5
