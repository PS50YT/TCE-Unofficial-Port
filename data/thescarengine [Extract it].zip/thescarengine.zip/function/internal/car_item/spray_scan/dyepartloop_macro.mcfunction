# 26.1.2: minecraft:dyed_color is stored as a direct RGB integer.
$data modify storage thescarengine:temp data.internal.spray_item.car_color_copy[{part:"$(part)"}].color set from storage thescarengine:temp data.internal.spray_item.used_data.components.minecraft:dyed_color
